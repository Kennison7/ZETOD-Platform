# ZeToD Python Skill Assessment Platform Architecture



